# Sonnets

Logan Hering

- First I found all amperstands and replaced them
Find: &
Replace with: &amp;

- Then I found all angle brackets and replaced them
Find: <
Replace with: &lt;
Find: >
Replace with: &gt;

- Then I found all groups of roman numerals and gave them chapter tags
Find: ([IVXLC]+)(\s\n)
Replace with: <chap>\1</chap>\2

- Then I added line tags around all lines
Find: ^.+
Replace with: <line>\0</line>

- Then I added sonnet tags with a numer attribute around each group of lines
Find: (</line>)(\n\n)
Replace with: \1</sonnet>\2<sonnet number="#">