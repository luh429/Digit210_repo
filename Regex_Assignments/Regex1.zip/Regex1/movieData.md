# Movie Regex

Logan Hering

First I looked for and replaced apersands.
    Find: &
    Replaced with: &amp;

Then I put "movie" tags around each line/movie.
    Find: ^.+
    Replace with: <movie>\0</movie>

Then I put "title" tags around the title of each movie
    Find: (<movie>)(.+?)\t
    Replace with: \1<title>\2</title>

Then I put "year" tags around the years
    Find:(</title>)(.+?)\t
    Replace with: \1<year>\2</year>

Then I repeated the same step as above but with the country and runtime